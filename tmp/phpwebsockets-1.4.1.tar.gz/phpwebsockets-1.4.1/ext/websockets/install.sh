#!/bin/sh

if [ ! -f 'modules/websockets.so' ];
then
	echo -en "No module file was found. Please build your module first. See README for details.\n";
fi;

PHPMDIR=`php -r 'print ini_get("extension_dir");'`/;
cp modules/websockets.so $PHPMDIR;
cp websockets.ini /etc/php.d/