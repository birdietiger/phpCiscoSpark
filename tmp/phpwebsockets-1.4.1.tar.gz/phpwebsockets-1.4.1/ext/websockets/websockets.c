/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

#include <zend_API.h>


/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_websockets.h"

/* Integer Types */
#include <stdint.h>
#include <string.h>

/* Functions this extension needs */
static uint64_t _php_websockets_ntoh_64(uint64_t num TSRMLS_DC);
static int _php_websockets_read_buffer(php_stream *socket, unsigned char *at, size_t len TSRMLS_DC);
static void _php_websockets_unmask(unsigned char *mask, unsigned char *at, size_t len, size_t offset TSRMLS_DC);

/* True global resources - no need for thread safety here */
static int le_websockets;

/* {{{ websockets_functions[]
 *
 * Every user visible function must have an entry in websockets_functions[].
 */
const zend_function_entry websockets_functions[] = {
	PHP_FE(ws_get_frame_info, NULL)	/* Reads information about the upcoming frame */
	PHP_FE(ws_read_frame, NULL)		/* Reads in the data of a frame */
	PHP_FE(ws_send_frame, NULL)		/* Sends a close frame and disconnects */
	PHP_FE(ws_send_close, NULL)		/* Sends a close frame */
	PHP_FE(ws_send_ping, NULL)		/* Sends a ping frame */
	PHP_FE(ws_send_pong, NULL)		/* Sends a pong frame */
	PHP_FE_END	/* Must be the last line in websockets_functions[] */
};
/* }}} */

/* {{{ websockets_module_entry
 */
zend_module_entry websockets_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"websockets",
	websockets_functions,
	PHP_MINIT(websockets),
	PHP_MSHUTDOWN(websockets),
	NULL, /* PHP_RINIT(websockets),		/* Replace with NULL if there's nothing to do at request start */
	NULL, /* PHP_RSHUTDOWN(websockets),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(websockets),
#if ZEND_MODULE_API_NO >= 20010901
	"1.3", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_WEBSOCKETS
ZEND_GET_MODULE(websockets)
#endif

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(websockets)
{
	/* If you have INI entries, uncomment these lines 
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(websockets)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(websockets)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "Websockets support", "enabled (V1.3)");
	php_info_print_table_end();
}
/* }}} */

/* {{{ proto array ws_get_frame_info(resource socket)
   Reads information about the upcoming websockets frame and returns that information as an array */
PHP_FUNCTION(ws_get_frame_info) {
	/* Function Header */
	
	/* The zval websocket stream */
	zval *zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* Frame metadata */
	unsigned char meta[12];
	
	/* Payload length */
	size_t len = 0;
	
	/* Payload length (2 bytes) */
	uint16_t len2 = 0;
	
	/* Payload length (8 bytes) */
	uint64_t len8 = 0;
	
	/* Fin Bit */
	int finbit = 0;
	
	/* RSV1 Bit */
	int rsv1bit = 0;
	
	/* RSV2 Bit */
	int rsv2bit = 0;
	
	/* RSV3 Bit */
	int rsv3bit = 0;
	
	/* Opcode */
	int opcode = 0;
	
	/* Mask Bit */
	int maskbit = 0;
	
	/* The read result */
	int readresult = 0;
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &zsocket) == FAILURE) {
        return;
    }
	
	/* Convert the input stream */
	php_stream_from_zval(socket, &zsocket);
	
	/* Initialize the return array */
	array_init(return_value);
	
	/* Add some initial data to the return array */
	add_assoc_bool(return_value, "success", 0);
	
	/* Add the socket to the return array */
	Z_ADDREF_P(zsocket);
	add_assoc_zval(return_value, "socket", zsocket);
	
	/* Read in the first 2 bytes */
	readresult = _php_websockets_read_buffer(socket, meta, 2 TSRMLS_CC);
	if (readresult != 0) {
		
		/* Set some info on the return array */
		add_assoc_string(return_value, "type", "unknown", 1);
		
		if (readresult == 1) {
			add_assoc_string(return_value, "error", "Could not read frame info from the socket. (Attempted to read 2 bytes)", 1);
		}
		
		else if (readresult == 2) {
			add_assoc_string(return_value, "error", "Could not read frame info from the socket. (Client was disconnected)", 1);
		}
		
		else if (readresult == 3) {
			add_assoc_string(return_value, "error", "Could not read frame info from the socket. (Read operation timed out)", 1);
		}
		
		return;
	}
	
	/* Parse the metadata */
	if (meta[0] & 128)	{ finbit = 1; }
	if (meta[0] & 64)	{ rsv1bit = 1; }
	if (meta[0] & 32)	{ rsv2bit = 1; }
	if (meta[0] & 16)	{ rsv3bit = 1; }
	if (meta[1] & 128)	{ maskbit = 1; }
	opcode = meta[0] & 15;
	
	/* Continuation frame */
	if (opcode == 0) {
		add_assoc_string(return_value, "type", "continuation", 1);
	}
	
	/* Text frame */
	else if (opcode == 1) {
		add_assoc_string(return_value, "type", "text", 1);
	}
	
	/* Binary frame */
	else if (opcode == 2) {
		add_assoc_string(return_value, "type", "binary", 1);
	}
	
	/* Close frame */
	else if (opcode == 8) {
		add_assoc_string(return_value, "type", "close", 1);
	}
	
	/* Ping frame */
	else if (opcode == 9) {
		add_assoc_string(return_value, "type", "ping", 1);
	}
	
	/* Pong frame */
	else if (opcode == 10) {
		add_assoc_string(return_value, "type", "pong", 1);
	}
	
	/* Unknown frame */
	else {
		add_assoc_string(return_value, "type", "unknown", 1);
	}
	
	/* Final bit set */
	add_assoc_bool(return_value, "final", finbit);
	
	/* RSV1 bit set */
	add_assoc_bool(return_value, "rsv1", rsv1bit);
	
	/* RSV2 bit set */
	add_assoc_bool(return_value, "rsv2", rsv2bit);
	
	/* RSV3 bit set */
	add_assoc_bool(return_value, "rsv3", rsv3bit);
	
	/* Opcode */
	add_assoc_long(return_value, "opcode", opcode);
	
	/* Mask bit set */
	add_assoc_bool(return_value, "masked", maskbit);
	
	/* Parse the length */
	len = meta[1] & 127;
	
	/* If the length is in the next 2 bytes */
	if (len == 126) {
		
		/* Read in 2 bytes */
		readresult = _php_websockets_read_buffer(socket, meta, 2 TSRMLS_CC);
		if (readresult != 0) {
			
			if (readresult == 1) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Attempted to read 2 bytes)", 1);
			}

			else if (readresult == 2) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Client was disconnected)", 1);
			}

			else if (readresult == 3) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Read operation timed out)", 1);
			}

			return;

		}
		
		/* Copy the 2 byte length into len2 and convert it to host byte order */
		memcpy(&len2, meta, 2);
		
		/* Then set it into len */
		len = (size_t)ntohs(len2);
	}
	
	/* If the length is in the next 8 bytes */
	else if (len == 127) {
		
		/* Read in 8 more bytes */
		readresult = _php_websockets_read_buffer(socket, meta, 8 TSRMLS_CC);
		if (readresult != 0) {
			
			if (readresult == 1) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Attempted to read 8 bytes)", 1);
			}

			else if (readresult == 2) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Client was disconnected)", 1);
			}

			else if (readresult == 3) {
				add_assoc_string(return_value, "error", "Could not read frame size from the socket. (Read operation timed out)", 1);
			}

			return;
		}

		/* Copy the 8 byte length into len8 and convert it to host byte order
		 * Um.. Hopefully, len8 fits in size_t. It should as long as a payload is not more than like 4 gigs..
		 * A payload should never be that large. I don't think there is a browser out there that can handle
		 * a websocket frame of that size without crashing.
		 */
		memcpy(&len8, meta, 8);
		
		/* Then set it into len */
		len = (size_t)_php_websockets_ntoh_64(len8 TSRMLS_CC);
	}
	
	/* Set the payload size */
	add_assoc_long(return_value, "size", len);
	
	/* Set success to true */
	add_assoc_bool(return_value, "success", 1);
	
	return;
	
}
/* }}} */

/* {{{ proto array ws_read_frame(array info, resource filehandle)
   Reads the websockets frame and returns information about the read */
PHP_FUNCTION(ws_read_frame) {
	/* Function Header */
	
	/* Holds the info array */
	zval *info;
	
	/* The zval websocket stream */
	zval **zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* The zval filehandle to write to */
	zval *zfilehandle = NULL;
	
	/* Whether or not we got a filehandle to write to */
	int passed_zfilehandle = 0;
	
	/* The PHP filehandle to write to stream resource */
	php_stream *filehandle;
	
	/* Whether or not we should write the output to a filehandle */
	int out_to_filehandle = 0;
	
	/* zval to hold an array of reads */
	zval *msgs;
	
	/* zval to hold the final message */
	zval *msg;
	
	/* zval to hold the implode userspace function name */
	zval *implode;
	
	/* zval to hold the implode glue */
	zval *glue;
	
	/* Holds the parameters to implode */
	zval **implode_params[2];
	
	/* Mask */
	unsigned char mask[6];
	
	/* zval pointer to determine if the frame info was successful */
	zval **was_successful;
	
	/* zval pointer to determine if the frame is masked */
	zval **is_masked;
	
	/* zval pointer to determine the opcode for the frame */
	zval **opcode;
	
	/* Whether the frame is masked or not */
	int masked = 0;
	
	/* Whether or not this is a close frame */
	int closeframe = 0;
	
	/* zval pointer to hold the payload size */
	zval **payload_size;
	
	/* The length of the frame */
	size_t len = 0;
	
	/* 8K buffer to hold data */
	unsigned char data[8200];
	
	/* Holds a pointer to the data buffer */
	unsigned char *dataptr;
	
	/* The number of bytes to read */
	size_t toread = 0;
	
	/* The number of bytes remaining */
	size_t remaining = 0;
	
	/* 2 byte Close Code */
	uint16_t close_code = 0;
	
	/* The read result */
	int readresult = 0;
	
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "a|r", &info, &zfilehandle) == FAILURE) {
        return;
    }
	
	/* See if we passed a filehandle */
	if (zfilehandle != NULL) {
		passed_zfilehandle = 1;
	}
	
	/* Initialize the return array */
	array_init(return_value);
	
	/* Set some initial data on the return array */
	add_assoc_bool(return_value, "success", 0);
	
	/* See if the frame info read was a success */
	if (zend_hash_find(Z_ARRVAL_P(info), "success", sizeof("success"), (void **)&was_successful) != SUCCESS || Z_TYPE_PP(was_successful) != IS_BOOL || (!Z_LVAL_PP(was_successful))) {
		
		/* Set some info in the return array */
		add_assoc_string(return_value, "error", "The frame info read was not successful. (The $info array parameter should contain a true success key)", 1);
		
		/* Issue a warning and return */
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "The frame info read was not successful. (The $info array parameter should contain a true success key)");
		return;
	}
	
	/* Get the payload size. Note: It is perfectly acceptable to have a payload size of 0 so no error handling is done. */
	if (zend_hash_find(Z_ARRVAL_P(info), "size", sizeof("size"), (void **)&payload_size) == SUCCESS && Z_TYPE_PP(payload_size) == IS_LONG && Z_LVAL_PP(payload_size) > 0) {
		len = (size_t)Z_LVAL_PP(payload_size);
	}
	
	/* Get and initialize the socket */
	if (zend_hash_find(Z_ARRVAL_P(info), "socket", sizeof("socket"), (void **)&zsocket) != SUCCESS || Z_TYPE_PP(zsocket) != IS_RESOURCE) {
		
		/* Set some info in the return array */
		add_assoc_string(return_value, "error", "No socket connection found. (The $info array parameter should contain a valid socket)", 1);
		
		/* Issue a warning and return */
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "No socket connection found. (The $info array parameter should contain a valid socket as the value of the socket key)");
		return;
	}
	
	/* Check if this is a close frame */
	if (zend_hash_find(Z_ARRVAL_P(info), "opcode", sizeof("opcode"), (void **)&opcode) == SUCCESS && Z_TYPE_PP(opcode) == IS_LONG && Z_LVAL_PP(opcode) == 8) {
		closeframe = 1;
	}
	
	/* Convert the input stream */
	php_stream_from_zval(socket, zsocket);
	
	/* See if the frame is masked */
	if (zend_hash_find(Z_ARRVAL_P(info), "masked", sizeof("masked"), (void **)&is_masked) == SUCCESS && Z_TYPE_PP(is_masked) == IS_BOOL && Z_LVAL_PP(is_masked)) {
		
		/* Read in 4 bytes and store it in the mask array */
		readresult = _php_websockets_read_buffer(socket, mask, 4 TSRMLS_CC);
		if (readresult != 0) {
			
			if (readresult == 1) {
				add_assoc_string(return_value, "error", "Could not read frame mask from the socket. (Attempted to read 4 bytes)", 1);
			}

			else if (readresult == 2) {
				add_assoc_string(return_value, "error", "Could not read frame mask from the socket. (Client was disconnected)", 1);
			}

			else if (readresult == 3) {
				add_assoc_string(return_value, "error", "Could not read frame mask from the socket. (Read operation timed out)", 1);
			}
	
			return;
		}
		
		/* Set the masked byte to t for true */
		masked = 1;
	}
	
	/* Check to see if we have an output filehandle */
	if (passed_zfilehandle == 1 && Z_TYPE_P(zfilehandle) == IS_RESOURCE) { 
		
		/* Convert the filehandle to a stream */
		php_stream_from_zval(filehandle, &zfilehandle);
		out_to_filehandle = 1;
	}
	
	/* Otherwise, initialize some zvals to handle 8K buffers */
	else {
		
		/* Make zvals */
		MAKE_STD_ZVAL(msgs);
		MAKE_STD_ZVAL(implode);
		MAKE_STD_ZVAL(glue);
		
		/* Set values */
		array_init(msgs);
		ZVAL_STRING(implode, "implode", 1);
		ZVAL_STRING(glue, "", 1);
		
	}
	
	/* Read in the frame data in chunks */
	remaining = len; 
	while (remaining > 0) {
		
		/* Read in up to the input buffer size */
		if (remaining > 8192) { toread = 8192; } else { toread = remaining; }
		
		readresult = _php_websockets_read_buffer(socket, data, toread TSRMLS_CC);
		if (readresult != 0) {
			
			if (readresult == 1) {
				add_assoc_string(return_value, "error", "Could not read frame data from the socket.", 1);
			}

			else if (readresult == 2) {
				add_assoc_string(return_value, "error", "Could not read frame data from the socket. (Client was disconnected)", 1);
			}

			else if (readresult == 3) {
				add_assoc_string(return_value, "error", "Could not read frame data from the socket. (Read operation timed out)", 1);
			}
			
			/* Cleanup */
			if (out_to_filehandle != 1) {
				zval_ptr_dtor(&msgs);
				zval_ptr_dtor(&implode);
				zval_ptr_dtor(&glue);
			}
			
			return;
		}
		
		/* Update remaining bytes */
		remaining -= toread;
		
		/* Unmask the data */
		if (masked == 1) {
			_php_websockets_unmask(mask, data, toread, 0 TSRMLS_CC);
		}
		
		/* Offset the data by 2 bytes if this is a close frame  */
		if (closeframe == 1) { 
			dataptr = data+2;
			toread -= 2;
		}
		
		/* Otherwise no offset */
		else { 
			dataptr = data; 
		}
		
		/* If we are to print this out to a filehandle */
		if (out_to_filehandle == 1) {
			php_stream_write(filehandle, dataptr, toread);
		}
		
		/* Otherwise, add it to the msgs array */
		else {
			add_next_index_stringl(msgs, dataptr, toread, 1);
		}
	}
	
	/* At this point, we got all the data */
	
	/* If we are not writing to a filehandle, then add the data to the return array */
	if (out_to_filehandle != 1) {
		
		/* Set parameters */
		implode_params[0] = &glue;
		implode_params[1] = &msgs;
		
		/* Implode all the messages (There may be a better way to do this than using the userspace implode function, but I couldn't figure out how... input welcome ray@snapws.com) */
		call_user_function_ex(CG(function_table), NULL, implode, &msg, 2, implode_params, 0, NULL TSRMLS_CC);
		
		/* Add the data to the return array */
		add_assoc_zval(return_value, "data", msg);
		
		/* Cleanup */
		zval_ptr_dtor(&msgs);
		zval_ptr_dtor(&implode);
		zval_ptr_dtor(&glue);
	}
	
	/* If this is a close frame, parse the close code */
	if (closeframe == 1) {	
		/* Make sure the payload length is at least 2 */
		if (len >= 2) {
			
			/* Copy the first 2 bytes into the close code */
			memcpy(&close_code, data, 2);
			
			/* Convert the code to host byte order */
			close_code = ntohs(close_code);
			
		}
		
		/* Add the close code to the return array */
		add_assoc_long(return_value, "closecode", (long)close_code);
	}
	
	/* OK, we are done, set success to true */
	add_assoc_bool(return_value, "success", 1);
	
}
/* }}} */

/* {{{ proto int ws_send_frame(resource socket, string message, string|int type, bool mask, bool final, bool rsv1, bool rsv2, bool rsv3)
   Sends a websockets frame and returns the number of payload bytes written */
PHP_FUNCTION(ws_send_frame) {
	/* Function Header */
	
	/* The zval representation of the websocket stream */
	zval *zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* The frame metadata */
	unsigned char meta[20];
	
	/* Pointer to the mask key in the metadata */
	unsigned char *mask;
	
	/* The length of the metadata */
	size_t metalen = 0;
	
	/* Pointer to the message to send */
	unsigned char *msg;
	
	/* Message length in bytes */
	size_t len = 0;
	
	/* 2 Byte message length */
	uint16_t len2 = 0;
	
	/* 8 Byte message length */
	uint64_t len8 = 0;
	
	/* zval for the frame type */
	zval *ztype = NULL;
	
	/* Whether or not the user passed a ztype parameter  */
	int passed_ztype = 0;
	
	/* Pointer to the string representation of the frame type  */
	unsigned char *frame_type_string;
	
	/* Length of the frame type string */
	size_t frame_type_string_len = 0;
	
	/* Long representation of the frame type  */
	unsigned long frame_type_long = 0;
	
	/* bool for masking the frame or not */
	zend_bool masked = 0;
	
	/* bool for setting the final bit or not */
	zend_bool final = 1;
	
	/* bool for setting the RSV1 bit or not */
	zend_bool rsv1 = 0;
	
	/* bool for setting the RSV2 bit or not */
	zend_bool rsv2 = 0;
	
	/* bool for setting the RSV3 bit or not */
	zend_bool rsv3 = 0;
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs|zbbbbb", &zsocket, &msg, &len, &ztype, &masked, &final, &rsv1, &rsv2, &rsv3) == FAILURE) {
		return;
    }
	
	/* See if we passed a ztype parameter */
	if (ztype != NULL) {
		passed_ztype = 1;
	}
	
	/* Convert the output stream */
	php_stream_from_zval(socket, &zsocket);
	
	/* If a frame type was passed */
	if (passed_ztype == 1) {
		/* Parse and set the frame type */
		switch (Z_TYPE_P(ztype)) {

			/* If it is a string... */
			case IS_STRING:

				/* Get the string and length */
				frame_type_string = Z_STRVAL_P(ztype);
				frame_type_string_len = Z_STRLEN_P(ztype);

				/* See if the type is a text frame */
				if (frame_type_string_len == 4 && strncmp("text", frame_type_string, 4) == 0) {
					meta[0] = 1;
				}

				/* See if it is a binary frame */
				else if (frame_type_string_len == 6 && strncmp("binary", frame_type_string, 6) == 0) {
					meta[0] = 2;
				}

				/* See if it is a close frame */
				else if (frame_type_string_len == 5 && strncmp("close", frame_type_string, 5) == 0) {
					meta[0] = 8;
				}

				/* See if it is a continuation frame */
				else if (frame_type_string_len == 12 && strncmp("continuation", frame_type_string, 12) == 0) {
					meta[0] = 0;
				}

				/* See if it is a ping frame */
				else if (frame_type_string_len == 4 && strncmp("ping", frame_type_string, 4) == 0) {
					meta[0] = 9;
				}

				/* See if it is a close frame */
				else if (frame_type_string_len == 4 && strncmp("pong", frame_type_string, 4) == 0) {
					meta[0] = 10;
				}

				break;

			/* If it is a long */
			case IS_LONG:

				/* Set the opcode to the numerical value only if it fits in the first 4 bits, otherwise set it to 1 for text */
				meta[0] = Z_LVAL_P(ztype) < 16 ? Z_LVAL_P(ztype) : 1;
				break;

			/* Default */
			default:

				/* Set it to text by default */
				meta[0] = 1;

		}
		
	/* Otherwise set it to text by default */
	} else {
		meta[0] = 1;
	}
	
	/* Set the fin bit if specified */
	if (final) {
		meta[0] += 128;
	}
	
	/* Set the RSV1 bit if specified */
	if (rsv1) {
		meta[0] += 64;
	}
	
	/* Set the RSV2 bit if specified */
	if (rsv2) {
		meta[0] += 32;
	}
	
	/* Set the RSV3 bit if specified */
	if (rsv3) {
		meta[0] += 16;
	}
	
	/* If the length fits in the first byte */
	if (len < 126) {
		meta[1] = len;
		metalen = 2;
	}
	
	/* If the length fits in the next 2 bytes */
	else if (len < 65536) {
		
		/* Set the length to 126 */
		meta[1] = 126;
		
		/* Cast the length to a 16 bit int and put it in len2 */
		len2 = (uint16_t)len;
		
		/* Convert len2 to network byte order */
		len2 = htons(len2);
		
		/* Copy the bytes to the metadata */
		memcpy(meta+2, &len2, 2);
		
		/* Set the meta length to 4 bytes */
		metalen = 4;
	}
	
	/* Else the length will fit in the next 8 bytes */
	else {
		
		/* Set the length to 127 */
		meta[1] = 127;
		
		/* Cast the length to a unsigned 64bit int, convert it network byte order and put it in len8 */
		len8 = _php_websockets_ntoh_64((uint64_t)len TSRMLS_CC);
		
		/* Copy len8 to the metadata */
		memcpy(meta+2, &len8, 8);
		
		/* Set the meta length to 10 bytes */
		metalen = 10;
	}
	
	/* If the frame is to be masked */
	if (masked) {
		
		/* Set the mask bit */
		meta[1] += 128;
		
		/* Set the mask key pointer */
		mask = meta + metalen;
		
		/* Set a random mask key */
		meta[metalen] = rand() & 0xff;
		meta[metalen+1] = rand() & 0xff;
		meta[metalen+2] = rand() & 0xff;
		meta[metalen+3] = rand() & 0xff;
		
		/* Increment the meta length by 4 bytes */
		metalen += 4;
		
		/* Mask the data. It's the same algorithm to mask as it is to unmask */
		_php_websockets_unmask(mask, msg, len, 0 TSRMLS_CC);
	}
	
	/* Write the frame metadata */
	php_stream_write(socket, meta, metalen);
	
	/* Write the frame data */
	php_stream_write(socket, msg, len);
	
	/* Return the length */
	RETURN_LONG(len);
	
}
/* }}} */

/* {{{ proto int ws_send_close(resource socket, int code, string reason, bool mask)
   Sends a close frame and returns the number of payload bytes written */
PHP_FUNCTION(ws_send_close) {
	/* Function Header */
	
	/* The zval representation of the websocket stream */
	zval *zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* The frame metadata */
	unsigned char meta[20];
	
	/* Pointer to the mask key in the metadata */
	unsigned char *mask;
	
	/* The length of the metadata */
	size_t metalen = 2;
	
	/* The closure code */
	long code = 1000;
	
	/* The 2 byte code */
	uint16_t code2;
	
	/* Pointer to the reason to send */
	unsigned char *reason;
	
	/* Message length in bytes */
	size_t rlen = 0;
	
	/* bool for masking the frame or not */
	zend_bool masked = 0;
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|lsb", &zsocket, &code, &reason, &rlen, &masked) == FAILURE) {
        return;
    }
	
	/* Convert the output stream */
	php_stream_from_zval(socket, &zsocket);
	
	/* Set the first byte of the meta to a close frame */
	meta[0] = 136;
	
	/* Only send the first 123 bytes of the reason */
	if (rlen > 123) { rlen = 123; }
	
	/* Set the length in the 2nd byte plus 2 bytes for the code */
	meta[1] = rlen+2;
	
	/* If the frame is to be masked */
	if (masked) {
		
		/* Set the mask bit */
		meta[1] += 128;
		
		/* Set the mask key pointer */
		mask = meta + metalen;
		
		/* Set a random mask key */
		meta[metalen] = rand() & 0xff;
		meta[metalen+1] = rand() & 0xff;
		meta[metalen+2] = rand() & 0xff;
		meta[metalen+3] = rand() & 0xff;
		
		/* Increment the meta length by 4 bytes */
		metalen += 4;
		
		/* Mask the data. It's the same algorithm to mask as it is to unmask.. Remember we have a 2 byte offset for the code */
		_php_websockets_unmask(mask, reason, rlen, 2 TSRMLS_CC);
	}
	
	/* Make sure the code is no larger than 2 bytes */
	if (code > 0xffff) { code = 0xffff; }
	
	/* Cast the code to a 2 byte code */
	code2 = (uint16_t)code;
	
	/* Make sure the code is in network byte order */
	code2 = htons(code2);
	
	/* Copy the code to the end of the meta and update the length */
	memcpy(meta+metalen, &code2, 2);
	
	/* Mask the code if masked is set */
	if (masked) {
		_php_websockets_unmask(mask, meta+metalen, 2, 0 TSRMLS_CC);
	}
	
	/* Increment the meta length 2 bytes */
	metalen += 2;
	
	/* Write the frame metadata */
	php_stream_write(socket, meta, metalen);
	
	/* Write the frame data */
	php_stream_write(socket, reason, rlen);
	
	/* Return the length */
	RETURN_LONG(rlen+2);
}
/* }}} */

/* {{{ proto int ws_send_ping(resource socket, string message, bool mask)
   Sends a ping frame and returns the number of payload bytes written */
PHP_FUNCTION(ws_send_ping) {
	/* The zval representation of the websocket stream */
	zval *zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* The frame metadata */
	unsigned char meta[20];
	
	/* Pointer to the mask key in the metadata */
	unsigned char *mask;
	
	/* The length of the metadata */
	size_t metalen = 2;
	
	/* Pointer to the message to send */
	unsigned char *msg;
	
	/* Message length in bytes */
	size_t len = 0;
	
	/* bool for masking the frame or not */
	zend_bool masked = 0;
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|sb", &zsocket, &msg, &len, &masked) == FAILURE) {
        return;
    }
	
	/* Convert the output stream */
	php_stream_from_zval(socket, &zsocket);
	
	/* Set the first byte of the meta to a ping frame */
	meta[0] = 137;
	
	/* Only send the first 125 bytes of the message */
	if (len > 125) { len = 125; }
	
	/* Set the length in the 2nd byte */
	meta[1] = len;
	
	/* If the frame is to be masked */
	if (masked) {
		
		/* Set the mask bit */
		meta[1] += 128;
		
		/* Set the mask key pointer */
		mask = meta + metalen;
		
		/* Set a random mask key */
		meta[metalen] = rand() & 0xff;
		meta[metalen+1] = rand() & 0xff;
		meta[metalen+2] = rand() & 0xff;
		meta[metalen+3] = rand() & 0xff;
		
		/* Increment the meta length by 4 bytes */
		metalen += 4;
		
		/* Mask the data. It's the same algorithm to mask as it is to unmask.. */
		_php_websockets_unmask(mask, msg, len, 0 TSRMLS_CC);
	}
	
	/* Write the frame metadata */
	php_stream_write(socket, meta, metalen);
	
	/* Write the frame data */
	php_stream_write(socket, msg, len);
	
	/* Return the length */
	RETURN_LONG(len);
}
/* }}} */

/* {{{ proto array ws_send_pong(resource socket, string message, bool mask)
   Sends a pong frame and returns the number of payload bytes written */
PHP_FUNCTION(ws_send_pong) {
	/* The zval representation of the websocket stream */
	zval *zsocket;
	
	/* The PHP websocket stream resource */
	php_stream *socket;
	
	/* The frame metadata */
	unsigned char meta[20];
	
	/* Pointer to the mask key in the metadata */
	unsigned char *mask;
	
	/* The length of the metadata */
	size_t metalen = 2;
	
	/* Pointer to the message to send */
	unsigned char *msg;
	
	/* Message length in bytes */
	size_t len = 0;
	
	/* bool for masking the frame or not */
	zend_bool masked = 0;
	
	/* Function Body */
	
	/* Get the parameters */
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|sb", &zsocket, &msg, &len, &masked) == FAILURE) {
        return;
    }
	
	/* Convert the output stream */
	php_stream_from_zval(socket, &zsocket);
	
	/* Set the first byte of the meta to a pong frame */
	meta[0] = 138;
	
	/* Only send the first 125 bytes of the message */
	if (len > 125) { len = 125; }
	
	/* Set the length in the 2nd byte */
	meta[1] = len;
	
	/* If the frame is to be masked */
	if (masked) {
		
		/* Set the mask bit */
		meta[1] += 128;
		
		/* Set the mask key pointer */
		mask = meta + metalen;
		
		/* Set a random mask key */
		meta[metalen] = rand() & 0xff;
		meta[metalen+1] = rand() & 0xff;
		meta[metalen+2] = rand() & 0xff;
		meta[metalen+3] = rand() & 0xff;
		
		/* Increment the meta length by 4 bytes */
		metalen += 4;
		
		/* Mask the data. It's the same algorithm to mask as it is to unmask.. */
		_php_websockets_unmask(mask, msg, len, 0 TSRMLS_CC);
	}
	
	/* Write the frame metadata */
	php_stream_write(socket, meta, metalen);
	
	/* Write the frame data */
	php_stream_write(socket, msg, len);
	
	/* Return the length */
	RETURN_LONG(len);
}
/* }}} */

/* {{{
 * Converts 64 bit integers from network to host (or host to network)
 */
static uint64_t _php_websockets_ntoh_64(uint64_t num TSRMLS_DC) {
	uint64_t rnum;			/* The number in reverse byte order */
	uint16_t b = 0;			/* Byte number */
	unsigned char *from;	/* Pointer to the byte to copy from */
	unsigned char *to;		/* Pointer to the byte to copy to */

	/* See if we need to reverse bytes or not */
	if (ntohs(200) == 200) { return num; }

	/* Yup, we need to reverse the byte order */

	/* Set the from and to byte pointers */
	from = (unsigned char *)&num+7;
	to = (unsigned char *)&rnum;

	/* Copy each byte from the from pointer to the to pointer in order */
	for (b=0; b<8; b++) {
		*to = *from;
		to++;
		from--;
	}

	/* Return the reverse ordered number */
	return rnum;

}
/* }}} */

/* {{{
 * Read from the buffer into a location in memory
 * Returns 0 on success, 1 on failure, 2 on eof, 3 on timeout
 */
static int _php_websockets_read_buffer(php_stream *socket, unsigned char *at, size_t len TSRMLS_DC) {
	size_t remaining = len;		/* Remaining bytes that have not been read yet. */
	size_t bytesread = 0;		/* The number of bytes that have already been read. */
	size_t totalbytesread = 0;	/* The total of all bytes read */
	size_t attempts = 0;		/* The number of attempts to read all the bytes available. */
	int eof = 0;				/* Holds EOF for the socket */
	
	/* Make sure we have an input stream */
	if (socket == NULL) { 
		return 1;
	}

	/* Get exactly as many bytes as we want. We need to loop and make sure exactly that many bytes were read until we get them all
	 * We never break out of this loop. We just keep going until we either 
	 * 1. Get the right number of bytes.
	 * 2. Get too many bytes
	 * 3. Get an EOF in which case, the client probably disconnected early
	 * 4. Get a 0 byte read which usually means the socket timed out. 
	 */
	while (remaining > 0) {
		attempts ++;
		bytesread = php_stream_read(socket, at, remaining);
		at += bytesread;
		remaining -= bytesread;
		totalbytesread += bytesread;
		
		/* See if we read in all the bytes we wanted */
		if (totalbytesread == len) { return 0; }
		
		/* If the bytes are more than what we needed.... this is bad. */
		if (totalbytesread > len) { 
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Read too many bytes while reading %zd bytes at byte %zd on read attempt %zd", len, totalbytesread, attempts);
			return 1;
		}
		
		/* If we are at EOF, or there is an error then return 2 because the connection has gone away. */
		eof = php_stream_eof(socket);
		if (eof != 0) { 
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Got eof while reading %zd bytes at byte %zd on read attempt %zd", len, totalbytesread, attempts);
			return 2; 
		}
		
		/* If we did not read any bytes this round, then our read operation timed out */
		if (bytesread == 0) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Socket read timeout while reading %zd bytes at byte %zd on read attempt %zd (0 bytes were read this attempt)", len, totalbytesread, attempts);
			return 3; 
		}
	}
	
}

/* {{{
 * Unmasks a data buffer given a 4 byte mask
 */
static void _php_websockets_unmask(unsigned char *mask, unsigned char *at, size_t len, size_t offset TSRMLS_DC) {
	size_t pos = 0;			/* The position of the unmasking operation */
	unsigned char *mpos;	/* The mask position */

	/* Make sure we have at least 1 byte to unmask */
	if (len < 1) { return; }
	
	/* Update the position to the offset byte */
	pos += offset;
	
	/* Add offset bytes to the length */
	len += offset;

	/* Unmask each byte of the buffer up to len bytes */
	for (pos=pos; pos<len; pos++) {
		mpos = mask + (pos%4);
		*at = *at ^ *mpos;
		at++;
	}
}
/* }}} */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
