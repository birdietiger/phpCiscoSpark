<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Websocket Client Test</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
	var WS = {};
	$(document).ready(function(e) {

		openWebSocket();
	});

	function openWebSocket() {
		// Open up the websocket connection to the server
		var protocol = ('https:' == document.location.protocol ? 'wss' : 'ws');
		WS.socket = new WebSocket(protocol + '://' + document.location.host);

		// On open event handler function
		WS.socket.onopen = function() {
			var msg = 'Hello server... This is the client. How are you?';
		};

		// On message event handler function
		WS.socket.onmessage = function(e) {
			var msg = jQuery('<div />').text(e.data).html();
			$('body').append('<div><strong>Received a message from the websocket server.</strong><pre><code>' + msg + '</code></pre></div>');
		};

		// On close event handler function
		WS.socket.onclose = function() {
			$('body').append('<div><strong>The websocket server closed the connection.</strong> <button type="button" onclick="openWebSocket();">Reconnect</button></div>')
		};
	}

	function sendThisFile() {
		var file = $('#myfile');
		var fileReader = new FileReader();
		fileReader.onloadend = function(e) {
			if (e.target.readyState == FileReader.DONE) {
				WS.socket.send(e.target.result);
			}
		}
		var msg = 'Sending a file to the server: '+file[0].files[0].name+' '+file[0].files[0].size+' bytes';
		$('body').append('<div><strong>'+msg+'</strong></div>');
		fileReader.readAsArrayBuffer(file[0].files[0]);
	}
	
	function sendThisMessage() {
		var msgtosend = $('#mymessage').val();
		var msg = jQuery('<div />').text(msgtosend).html();
		$('body').append('<div><strong>Sending a message to the websocket server:</strong><pre><code>' + msg + '</code></pre></div>');
		WS.socket.send(msgtosend);
	}


</script>
<style type="text/css">
div {
	padding:10px;
	margin-bottom: 10px;
	border: solid 1px #ccc;
}
</style>
</head>
<body>
<h1>You should see some activity below if your websockets server is running correctly.</h1>
Try sending a message or a file - Not too big of a file or the browser will crash<br />
<br />&nbsp;<br />
<div>
	Send some text and the server will respond that it received the message.<br />
	If you send the phrase "Send File" the server will send a random binary file.<br />
	If you send the phrase "Close Me" the server will close the connection.<br />
	<textarea cols="50" rows="10" name="mymessage" id="mymessage"></textarea><br />
	<button type="button" onclick="sendThisMessage();">Send Message</button><br />
</div>
<div>
	To send a file: <input type="file" name="myfile" id="myfile" />
	<button type="button" onclick="sendThisFile();">Send File</button>
</div>
<br />

<div>
	To close the connection: <button type="button" onclick="WS.socket.close();">Close connection</button>
</div>
<hr />
<h3>Websocket Server Log:</h3>
</body>
</html>