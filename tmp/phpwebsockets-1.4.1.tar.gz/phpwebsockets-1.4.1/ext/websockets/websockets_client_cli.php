<?php

/**
 * REMEMBER, THIS IS AN EXAMPLE OF A PHP WEBSOCKETS CLIENT
 * You should use this code as an example to create your own websockets client.
 * There are a lot of things this example does not handle like
 * - Should be implemented as a class
 * - Should have better error handling
 * - Should have better logging
 * - Should actually do something when sending / receiving messages
 * - There is probably a lot more I haven't mentioned.
 */

error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR);
ini_set('display_errors', 1);

/* Open up a socket to the server */
$socket = stream_socket_client("tcp://localhost:10000", $errno, $errstr);

/* Make sure we have a socket */
if (!$socket) {
	die("{$errstr} ({$errno})\n");
}

/* Negotiate the websocket connection */

/* Get Header */
fwrite($socket, "GET / HTTP/1.1\r\n");

/* Upgrade to websocket headers */
fwrite($socket, "Upgrade websocket\r\n");
fwrite($socket, "Connection Upgrade\r\n");

/* Send a random websocket key */
$key = base64_encode(md5(uniqid(rand(), true), true));
fwrite($socket, "Sec-WebSocket-Key {$key}\r\n");

/* Send the websocket version */
fwrite($socket, "Sec-WebSocket-Version 13\r\n\r\n");

/* Read in all headers from the server */
$inheaders = array();
while (true) {
	$line = trim(fgets($socket));
	if (!strlen($line)) { break; }

	list($name, $param) = explode(' ', $line, 2);
	$name = strtolower(preg_replace("/:$/", '', $name));
	$inheaders[$name] = $param;
}

/* Make sure that the websocket server accepted our connection */
if (trim(base64_encode(sha1($key . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true))) != $inheaders['sec-websocket-accept']) {
	die("The websocket server did not accept our connection\n");
}

/* Now we can send websocket frames to the server... Remember, since we are the client, we must mask the frames */
ws_send_frame($socket, "Test message", 'text', true);

/* Read the response */
$info = ws_get_frame_info($socket);
print "Frame Info: ";
print_r($info);

$data = ws_read_frame($info);
print "Frame Data: ";
print_r($data);

/* Send a fragmented frame set - See RFC6455 on Fragmentation */

/* The first frame must not have the final bit set, and have an opcode for the frame type (Set the frame type on the first frame) */
ws_send_frame($socket, "Line 1 of the fragmented message\n", "text", true, false);

/* Middle frames must not have the final bit set and must have an opcode of 0 (Or continuation frame type) */
ws_send_frame($socket, "Line 2 of the fragmented message\n", "continuation", true, false);
ws_send_frame($socket, "Line 3 of the fragmented message\n", 0, true, false); /* Same as the previous line as the opcode is set to 0 */

/* The final frame must have the final bit set and must have an opcode of 0 (Or continuation frame type) */
ws_send_frame($socket, "Final line of the fragmented message", "continuation", true, true);

/* Read the response */
$info = ws_get_frame_info($socket);
print "Frame Info: ";
print_r($info);

$data = ws_read_frame($info);
print "Frame Data: ";
print_r($data);

/* Send a close frame */
// ws_send_close($socket, 1000, "Im going away now.");

/* Send the message Close Me */
ws_send_frame($socket, "Close Me", "text", true);

/* Read the response */
$info = ws_get_frame_info($socket);
print "Frame Info: ";
print_r($info);

$data = ws_read_frame($info);
print "Frame Data: ";
print_r($data);

exit;