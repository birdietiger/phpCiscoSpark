<?php

/**
 * REMEMBER, THIS IS AN EXAMPLE OF A PHP WEBSOCKETS SERVER
 * You should use this code as an example to create your own server.
 * There are a lot of things this example does not handle like
 * - Starting and stopping the service
 * - Should have better error handling
 * - Should have better logging
 * - Should actually do something when receiving messages
 * - There is probably a lot more I haven't mentioned.
 *
 * This code is meant to inspire developers to create.... the sky is not the limit.
 */

// error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR);
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* Create a new WebSocketServer class */
$server = new WebSocketServer();

/* Enable or disable SSL. */
$server->enable_ssl = false;

/* Set the port */
$server->port = 10000;

/* You can set other properties of the $server object instance before starting the server */

/* Start the server */
$server->startServer();


/**
 * WebSocketsServer Class
 * 
 * You can use this class as a base class for your own Web Sockets server
 * Simply extend this class and override whatever methods you see fit.
 * 
 * This is a preforking websockets server capable of handling multiple
 * sumultaneous requests.
 */
class WebSocketServer {
	
	/**
	 * Whether or not SSL should be enabled.
	 * If true, then you must use https://hostname
	 * when pointing your browser to this server
	 * If enabled, you will need a valid SSL certificate
	 * If you don't have one, the server can handle
	 * creating a self signed SSL cert for you.
	 * 
	 * NOTE: After testing, we found that Safari won't work with a self signed SSL cert.
	 * With Safari, the SSL cert MUST be issued by a trusted certificate authority such as GeoTrust.
	 * If you need an SSL certificate, contact support@snapws.com and get free installation
	 * and configuration with the purchase of a certificate. At the time of this writing, (1-25-2013)
	 * we sell SSL certs starting at $99
	 * 
	 * @var boolean
	 */
	public $enable_ssl = false;
	
	/**
	 * Path to the SSL certificate to use when SSL is enabled
	 * Ignored unless {@link WebSocketServer::$enable_ssl} is true
	 * This can be a relative or absolute path. 
	 * If the certificate don't exist, it will be created
	 * automatically for you.
	 * @var string
	 */
	public $ssl_cert = 'sslcert.pem';
	
	/**
	 * Listen on IP Address.
	 * Set this to the listener IP address.
	 * 0.0.0.0 for to listen on all ip addresses.
	 * @var string
	 */
	public $listen_on = '0.0.0.0';
	
	/**
	 * Set this to the tcp port you want to liste on.
	 * @var int
	 */
	public $port = 10000;
	
	/**
	 * Set to the number of listening servers to spawn
	 * The more servers you spawn, the more simultaneous
	 * connections you can handle. This server is a multi
	 * process server and is capable of handling multiple
	 * connections at once. 
	 * 
	 * NOTE: This is NOT the number of simultaneous connections
	 * that you can handle. This server can handle unlimited
	 * multiple simultaneous connections. This property only
	 * specifies the number of processes listening for connections
	 * at the same time. When a connection is made, one of the
	 * listeners pick up the connection, negotiate the connection
	 * including SSL if enabled and then the listener forks a handler
	 * process and continues listening. So, why not just have a single
	 * listener process? Because it takes time to negotiate the
	 * connection, fork a handler process, and get back to listening.
	 * 
	 * In real life, if you only have a single listener and a connection
	 * comes in during the time that the listener is negotiating, you
	 * could lose the connection.
	 * 
	 * @var int
	 */
	public $listeners = 10;
	
	/**
	 * This is the socket resource that is created by
	 * stream_socket_server
	 * @var resource
	 */
	public $socket = false;
	
	/**
	 * The connection resource that is used to write to
	 * and read from the client
	 * @var resource
	 */
	public $connection = false;
	
	/**
	 * Holds an simple indexed array that describes the client
	 * including ip address[0] and port[1]
	 * @var type 
	 */
	public $client = array();
	
	/**
	 * Holds an array of HTTP headers that were sent from the
	 * client. Keys are the header parameter and values are the header values.
	 * @var array 
	 */
	public $headers = array();
	
	/**
	 * Construct a new object
	 */
	public function __construct() {
		/* Never time out */
		set_time_limit(0);
		
		/* Handle Signals */
		declare(ticks = 1);
		
		/* Handler for reaping children so we don't end up with zombies */
		pcntl_signal(SIGCHLD, array('WebSocketServer', 'reapChild'));
		
	}
	
	/**
	 * Call this method to start the server
	 */
	public function startServer() {
		/* If we want to enable SSL */
		if ($this->enable_ssl) {
			
			/* Set the SSL cert if it is not set */
			if (!strlen($this->ssl_cert)) { $this->ssl_cert = 'sslcert.pem'; }
			
			/* If the SSL cert doesn't exist, create a self signed one */
			if (!file_exists($this->ssl_cert)) { $this->createSslCert(); }
			
			/* Create the SSL context */
			$context = stream_context_create();
			stream_context_set_option($context, 'ssl', 'local_cert', $this->ssl_cert);
			stream_context_set_option($context, 'ssl', 'allow_self_signed', true);
			stream_context_set_option($context, 'ssl', 'verify_peer', false);
			$this->socket = stream_socket_server("tcp://{$this->listen_on}:{$this->port}", $errno, $errstr, STREAM_SERVER_BIND|STREAM_SERVER_LISTEN, $context);
			
			/* Disable SSL for now because we can't fork with SSL.. No worries, we will enable SSL later */
			stream_socket_enable_crypto($this->socket, false);
		}
		
		/* Otherwise, we just need to create a basic stream socket */
		else {
			$this->socket = stream_socket_server("tcp://{$this->listen_on}:{$this->port}", $errno, $errstr);
		}
		
		/* Make sure we have a valid socket */
		if (!$this->socket) {
			die("ERROR: Could not create socket server {$errstr}\n");
		}
		
		/* If we get here, we are a socket server. */
		print "Listening for connections on port {$this->port}\n\n";
		
		/* Fork the correct number of listeners */
		for ($i=0; $i<$this->listeners; $i++) {
			$this->addListener();
		}
		
		/* Now, we just need to handle signals */
		pcntl_signal(SIGTERM,	array('WebSocketServer', 'stopServer'));
		pcntl_signal(SIGHUP,	array('WebSocketServer', 'stopServer'));
		pcntl_signal(SIGINT,	array('WebSocketServer', 'stopServer'));
		
		/* Loop forever just to handle signals.. Mainly for shutting down the listeners on kill  */
		while (true) { 
			/* Sleep for a moment to avoid taking up too many cpu cycles */
			usleep(500000); 
		}
		
	}
	
	/**
	 * Adds a listener. The more listeners
	 * the more simultaneous connections we can handle.
	 * @return $this
	 */
	public function addListener() {
		
		/* Fork a listener process */
		$pid = pcntl_fork();
		if ($pid < 0) { die("FATAL: Could not fork a listener process"); }
		
		/* If we are the parent, we are done here. */
		if ($pid) { return $this; }
		
		/* Listen for connections in an infinite loop until killed */
		while (true) { $this->listenForConnection(); }
				
	}
	
	/**
	 * Listens for connections
	 * @return $this
	 */
	public function listenForConnection() {
		
		/* Accept a connection. Timeout every 5 seconds to keep the daemon fresh and handle signals */
		$this->connection = @stream_socket_accept($this->socket, 5, $this->client);
		
		/* If we have no connection, just return. */
		if (false == $this->connection) { return; }
		
		/* If we get here, we got a connection. Handle it. */
		$this->handleConnection();
		
		return $this;
		
	}
	
	/**
	 * Handles a connection
	 * @return $this
	 */
	public function handleConnection() {
		
		/* Fork a handler process */
		$pid = pcntl_fork();
		if ($pid < 0) { die("FATAL: Could not fork a handler process"); }
		
		/* If we are the parent, close the connection and return */
		if ($pid) { fclose($this->connection); return $this; }
		
		/* From here on, we are the handler process... Never return, handle the connection and exit */
		
		/* Parse the client address */
		$this->client = explode(':', $this->client);
		$this->doLog("Accepted a connection from {$this->client[0]}");
		
		/* Set blocking on the connection */
		stream_set_blocking($this->connection, 1);
		
		/* Setting a timeout will make sure that clients don't stay connected forever. */
		stream_set_timeout($this->connection, 10);
		
		/* Enable SSL on the connection if ssl is enabled */
		if ($this->enable_ssl) {
			if (!(stream_socket_enable_crypto($this->connection, true, STREAM_CRYPTO_METHOD_SSLv3_SERVER))) { 
				$this->dolog("ERROR: Could not negotiate SSL");
				die();
			}
			$this->doLog("Negotiating SSL on the connection.... [ OK ]");
		}
		
		/* OK, read input headers from the client */
		$this->readInputHeaders();
		
		/* Handle a websockets request */
		if (array_key_exists('upgrade', $this->headers)) {
			if (strtolower($this->headers['upgrade']) == 'websocket') {
				$this->handleWebSocketRequest();
			}
		}
		
		/* Handle serving the client file */
		else {
			$this->handleClientFileRequest();
		}
		
		/* If we get here, we are done handling the client. Just exit */
		exit;
		
	}
	
	/**
	 * Reads input HTTP headers from the client
	 * and stores them in {@link WebSocketServer::$headers}
	 * @return $this
	 */
	public function readInputHeaders() {
		/* Initialize headers */
		$this->headers = array();
		
		/* At this point, we just have a regular HTTP socket connection
		 * so we have to read in the headers and either serve a regular HTTP response
		 * or upgrade the connection to a valid websockets connection... More on that later.
		 */
		while (true) {
			/* Read a line from the client */
			$line = trim(fgets($this->connection));
			
			/* If the line is blank, we are done with headers */
			if (!strlen($line)) { break; }
			
			/* Parse the line into a name and value */
			list($name, $value) = explode(' ', $line, 2);
			$name = strtolower(preg_replace("/:$/", '', $name));
			
			/* Add the header to the headers arrray */
			$this->headers[$name] = $value;
			
		}
		
		return $this;
	}
	
	/**
	 * Handles serving the client file to the client over HTTP
	 */
	public function handleClientFileRequest() {
		
		/* At this point, we are just a regular HTTP server.
		 * You could actually just override this method to serve
		 * any type of file to the client over regular HTTP,
		 * but all we are going to do here is serve the
		 * websockets_client.php file and exit
		 */
		
		/* Make sure we want the client file. Should be a get of / */
		if (array_key_exists('get', $this->headers)) {
			if (!preg_match("/^\/\s/", $this->headers['get'])) { exit; }
		} else {
			exit;
		}
		
		/* Start output buffering so we can output the file after sending HTTP headers */
		ob_start();
		
		/* Execute the websockets_client.php file */
		include('websockets_client.php');
		
		/* Get the content in the output buffer */
		$clienthtml = ob_get_clean();
		
		/* Set HTTP headers */
		$headers = array();
		$headers[] = "HTTP/1.1 200 OK";
		$headers[] = "Date: " . date('r', time());
		$headers[] = "Server: PHP Websocket Server " . trim(gethostname());
		$headers[] = "Connection: close";
		$headers[] = "Content-Type: text/html; charset=UTF-8";
		$headers[] = "Content-Length: " . strlen($clienthtml);
		
		/* Send the headers to the browser */
		fwrite($this->connection, implode("\r\n", $headers));
		
		/* Send the separator between the headers and content */
		fwrite($this->connection, "\r\n\r\n");
		
		/* Send the HTML content */
		fwrite($this->connection, $clienthtml);
		
		/* Log this */
		$this->doLog("Sent client file (websockets_client.php) to the browser.");
		
		/* Done */
		exit;
	}
	
	/**
	 * Handles a Web Socket request
	 */
	public function handleWebSocketRequest() {
		
		/* Tell the browser to upgrade to a websocket connection. */
		fwrite($this->connection, "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " . trim(base64_encode(sha1($this->headers['sec-websocket-key'] . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true))) . "\r\n\r\n");
	
		/* At this point, we have a valid websockets connection.
		 * Now we can freely read and write to the websocket connection using
		 * {@link ws_get_frame_info()}, 
		 * {@link ws_read_frame()},
		 * {@link ws_send_frame()},
		 * {@link ws_send_close()},
		 * {@link ws_send_ping()}, and
		 * {@link ws_send_pong()}
		 * 
		 * functions.
		 * 
		 * Keep reading until the connection is closed
		 */
		while (true) {
			
			/* Read data from the client
			 * The {@link WebSocketServer::readWsMessageFromClient()} function handles the websocket protocol
			 * including text, binary, fragmented, and control frames. 
			 * 
			 * @see WebSocketServer::readWsMessageFromClient()
			 */
			$data = $this->readWsMessageFromClient();
			
			/* If this was a text message */
			if ($data['type'] == 'text') {
				$this->doLog('CLIENT SAID: ' . $data['message']);

				/* If the client said Close Me, close the connection */
				if ($data['message'] == 'Close Me') {
					ws_send_close($this->connection, 1000, "OK, I am closing the connection");
					$this->doLog("CLOSED CONNECTION: Closed the websocket connection");
					exit;
				}

				/* If the client said Send File, send some random binary data */
				if ($data['message'] == 'Send File') {
					ws_send_frame($this->connection, sha1(uniqid(rand(), true), true), 'binary');
					$this->doLog('SEND DATA TO CLINET: Sent 20 bytes of random binary data to the client');
					continue;
				}

				/* Tell the client we got their message */
				$msg = "Got Your Message of " . $data['size'] . ' byte(s)';
				ws_send_frame($this->connection, $msg);
				$this->doLog('TOLD CLIENT: ' . $msg);
				continue;
			}

			/* If this was a binary message */
			else if ($data['type'] == 'binary') {

				/* Calculate the md5 of the file */
				$md5 = md5_file($data['file']);

				$this->doLog('CLIENT SENT FILE: ' . $data['file'] . ' with md5 of ' . $md5);

				/* Send a response */
				$msg = "Got your file with checksum of " . $md5 . ' and ' . $data['size'] . ' byte(s)';
				ws_send_frame($this->connection, $msg);
				$this->doLog('TOLD CLIENT: ' . $msg);
				continue;
			}

			else {
				ws_send_close($this->connection);
				$this->doLog('UNKNOWN MESSAGE TYPE: This should never happen... But OK.. exiting.');
				die();
			}
		}
	}
	
	/**
	 * Reads a Web Socket message from the client and returns
	 * an array that describes the message.
	 * @return array
	 */
	public function readWsMessageFromClient() {
		/* Initialize some variables */
		$fh = false;
		$message = '';
		$bytes = 0;
		$type = false;
		$framecnt = 0;

		/* Process at least 1 frame. This allows us to handle fragmented frames as well as unfragmented frames. */
		do {

			$framecnt++;

			/* Get frame info from the peer */
			$info = ws_get_frame_info($this->connection);

			/* If any of the RSV bits are set, fail the connection */
			if ( ($info['rsv1']) || ($info['rsv2']) || ($info['rsv3']) ) {
				ws_send_close($this->connection, 1010, "ERROR: We didn't negotiate the extension you are trying to use.");
				$rsv = $info['rsv1']?'1':'0';
				$rsv .= $info['rsv2']?'1':'0';
				$rsv .= $info['rsv3']?'1':'0';
				$this->doLog("EXTENSION ERROR: Client sent a frame with the following RSV bits: {$rsv}");
				die();
			}

			/* If this is a binary frame */
			if ($info['type'] == 'binary') {

				/* Make sure this is the first frame */
				if ($framecnt != 1) {
					ws_send_close($this->connection, 1002, "ERROR: Expected opcode of 0 for fragmented frameset.");
					$this->doLog("PROTOCOL ERROR: Client sent a binary frametype in the middle of a fragmented frameset.");
					die();
				}

				/* Open up a filehandle to store the file */
				$tmpfile = tempnam('/tmp', 'php_websockets_file_');
				$fh = fopen($tmpfile, 'w');

				/* Read the frame into the opened file handle */
				$data = ws_read_frame($info, $fh);

				/* Set the size and type */
				$bytes = $info['size'];
				$type = 'binary';
			}

			/* If this is a text frame */
			elseif ($info['type'] == 'text') {

				/* Make sure this is the first frame */
				if ($framecnt != 1) {
					ws_send_close($this->connection, 1002, "ERROR: Expected opcode of 0 for fragmented frameset.");
					$this->doLog("PROTOCOL ERROR: Client sent a text frametype in the middle of a fragmented frameset.");
					die();
				}

				/* Read in the frame and set the data into $message */
				$data = ws_read_frame($info);
				$message = $data['data'];

				/* Set the size and type */
				$bytes = $info['size'];
				$type = 'text';
			}

			/* If this is a continuation frame */
			elseif ($info['type'] == 'continuation') {

				/* Make sure this is not the first frame */
				if ($framecnt < 2) {
					ws_send_close($this->connection, 1002, "ERROR: Expected opcode of 1 or 2 for first frame.");
					$this->doLog("PROTOCOL ERROR: Client sent a continuation frametype as the first frame.");
					die();
				}

				/* Handle text continuations */
				if ($type == 'text') {
					$data = ws_read_frame($info);
					$message .= $data['data'];
				}

				/* Handle binary continuations */
				else if ($type == 'binary') {
					$data = ws_read_frame($info, $fh);
				}

				/* Increment the size */
				$bytes += $info['size'];
			}

			/* If this is a close frame, send a close frame back and exit. */
			elseif ($info['type'] == 'close') {
				$data = ws_read_frame($info);
				ws_send_close($this->connection, $data['closecode']);
				$this->doLog("The client closed the connection ({$data['closecode']})... {$data['data']}");
				die();
			}

			/* If this is a ping frame, send a pong frame back */
			elseif ($info['type'] == 'ping') {
				$data = ws_read_frame($info);
				ws_send_pong($info['socket']);
				$this->doLog("The client sent a ping frame... Sent a pong frame in response.");
				continue;
			}

			/* If this is a pong frame, just read in the frame so that we can continue processing additional frames */
			elseif ($info['type'] == 'pong') {
				$data = ws_read_frame($info);
				$this->doLog("The client sent a pong frame letting us know it is still connected.");
				continue;
			}

			/* If the frame type is unknown */
			else {
				ws_send_close($this->connection, 1003, "ERROR: I don't understand the type of data you are trying to send.");
				$this->doLog("UNKNOWN FRAME TYPE: The client sent a frame with an opcode of " . $info['opcode'] . "\nERROR INFO: " . $info['error']);
				die();
			}

			/* If this is the final frame, break free */
			if ($info['final']) { break; }

		/* Keep reading frames until we get the last one
		 * 
		 * TODO: If the frame type is text and the text is too
		 * large, then the max memory will be exhausted and this
		 * handler process will crash. This is expecially true
		 * with streaming text frames that never end. Binary frames
		 * don't have that problem because they write the content to
		 * disk. Maybe there should be a way to handle that. Something
		 * like a MAX parameter that determines how large a message can
		 * be whether it is a fragmented message or not.
		 */
		} while (true);

		/* Setup the return array */
		$return = array(
			'type' => $type,
			'size' => $bytes,
			'framecnt' => $framecnt
		);

		/* If the type was binary */
		if ($type == 'binary') {
			/* Close the file handle if this is a binary message */
			fclose($fh);

			/* Add the file to the return array */
			$return['file'] = $tmpfile;
		}

		/* If the type was text */
		else if ($type == 'text') {
			$return['message'] = &$message;
		}

		return $return;
	}
	
	/**
	 * Creates a self signed SSL certificate
	 * @return $this
	 */
	public function createSslCert() {
		
		/* Get the parameters for generating a self signed SSL cert */
		$hostname = gethostname();
		$pem_dn = array(
			"countryName" => "US",							// Set your country name
			"stateOrProvinceName" => "Texas",				// Set your state or province name
			"localityName" => "Austin",						// Set your city name
			"organizationName" => "Your Company",			// Set your company name
			"organizationalUnitName" => "Your Department",	// Set your department name
			"commonName" => $hostname,						// Set your full hostname.
			"emailAddress" => "ssladmin@" . $hostname		// Set your email address
		);

		/* Create private key */
		$privkey = openssl_pkey_new();

		/* Create and sign CSR */
		$cert = openssl_csr_new($pem_dn, $privkey);
		$cert = openssl_csr_sign($cert, null, $privkey, 10000);

		/* Generate PEM file */
		$pem = array('', '');
		openssl_x509_export($cert, $pem[0]);
		openssl_pkey_export($privkey, $pem[1]);
		$pem = implode($pem);

		/* Save PEM file */
		file_put_contents($this->ssl_cert, $pem);
		chmod($this->ssl_cert, 0600);
		
		/* Make sure the file exists */
		clearstatcache();
		if (!file_exists($this->ssl_cert)) { die("Could not create a self signed SSL certificate"); }
		
		return $this;
	}
	
	/**
	 * Logs a message to the console.
	 * @param string $msg
	 */
	public function doLog($msg) {
		
		/* To turn off logging, uncomment the next line
		 * return;
		 */
		
		print getmypid() . ' - ' . trim($msg) . "\n";
	}
	
	/**
	 * Reap children so we don't end up with zombies
	 */
	public static function reapChild() {
		/* Reap all waiting children */
		while( pcntl_waitpid(-1, $status, WNOHANG) > 0 ) { }
	}
	
	/**
	 * Stops the server and exits
	 * @param int $signo
	 */
	public static function stopServer($signo) {
		// Get the pid
		$pid = getmypid();

		/* Start the tree out with the mail process ID */
		$tpids = array($pid);

		/* Recursively get the process tree */
		for ($i=0; $i<count($tpids); $i++) {

			/* Set the pid to get child pids of */
			$cpid = $tpids[$i];

			/* For safety to make sure no obscure characters get sent to the shell */
			$cpid += 0;

			/* Get all the child pids */
			$clist = preg_split("/\n/", trim(shell_exec("ps -o pid --no-headers --ppid $cpid")));

			/* Put all the child pids into the list of pids */
			foreach ($clist as $c) {
				$c+=0;
				if (!$c) { continue; }
				$tpids[] = $c; 
			}
		}

		/* Shift off the first process ID, (This process ID) bc we don't want to kill ourself */
		array_shift($tpids);

		/* Reverse the $tpids array so we start with the last child */
		$tpids = array_reverse($tpids);

		/* OK, we should have a full process tree to kill */
		foreach($tpids as $p){ 

			/* Try to kill the process up to 10 times just to make sure it's really dead */
			for ($i=0;$i<10;$i++) {

				$killed = posix_kill($p, SIGKILL);
				if ($killed) { break; }
			}

		}

		print "Killed the all listener and handler processes:\n";
		print_r($tpids);

		/* We are done. Exit. */
		exit();
	}
}


