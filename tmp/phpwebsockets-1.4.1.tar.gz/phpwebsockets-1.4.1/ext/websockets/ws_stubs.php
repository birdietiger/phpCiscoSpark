<?php

/**
 * Websockets Stub file
 * 
 * Never include this file as it only documents the functions in this file.
 * The actual functions are included in the websockets php extension.
 * The purpose of this file is to properly document each of the core functions
 * provided by this extension. If you are using an IDE to code such as Netbeans
 * or PHPStorm, you can put this file anywhere in your project to take advantage
 * of code hinting for these functions.
 * 
 * @author Ray Perea <ray@snapws.com>
 */

/**
 * Gets information about the upcoming websockets frame.
 * 
 * This will give you information about the next upcoming websocket frame so that you can decide
 * whether or not you want to read the data it contains. If you want to read the data contained
 * in the upcoming frame, simply call {@link ws_read_frame()} on the socket to retrieve the data.
 * WARNING!! You MUST call this {@link ws_get_frame_info()} followed by {@link ws_read_frame()}
 * in order to successfully read a frame as the 2 functions depend on each other.
 * If you decide not to read in the upcoming frame, then you SHOULD _Fail the connection by sending
 * a close frame using the {@link ws_send_close()} function.
 * The return array should look like this:
 * <div style="background:white;padding:10px;"><pre>
 * array(
 *   'success' => true,  // bool   - Whether the read operation was a success
 *   'socket' => {sock}, // resour - The socket resource as passed in by the $socket parameter
 *   'type' => 'text',   // string - The frame type. text, binary, close, ping, pong, continuation, unknown
 *   'final' => true,    // bool   - Whether this is the final frame or not. False for a continuation of the last frame
 *   'rsv1' => false,    // bool   - Whether or not the RSV1 bit is set. Used for extensions
 *   'rsv2' => false,    // bool   - Whether or not the RSV2 bit is set. Used for extensions
 *   'rsv3' => false,    // bool   - Whether or not the RSV3 bit is set. Used for extensions
 *   'opcode' => 1,      // int    - The opcode. This is the 4 bit opcode. Advanced usage only. 
 *   'masked' => true,   // bool   - Whether or not the frame is masked.
 *   'size' => 10000,    // int    - The size of the frame in bytes.
 *   'error' => '',      // string - If something went wrong, it will be set here.
 * );
 * </pre></div>
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param resource	$socket The web sockets stream connection to get the frame information from
 * @return array	An array that holds information about the upcoming frame.
 */
function ws_get_frame_info($socket) { }

/**
 * Reads the data of a websockets frame.
 * 
 * This will read the data in the next websockets frame and either
 * return that data or write it out to an open writable filehandle.
 * If you pass the $filehandle parameter, make sure it is an open writable file handle.
 * If you do not pass the $filehandle parameter, then the data will be in the return array.
 * The return array should look like this:
 * <div style="background:white;padding:10px;"><pre>
 * array(
 *   'success' => true,     // bool   - Whether the read operation was a success
 *   'data' => 'Message',   // string - The data that was read. This is only set if you did not pass in the $filehandle parameter
 *   'closecode' => 1000,   // int    - If this was a close frame, then the close code sent by the peer is set here.
 *   'error' => ''          // string - If anything went wrong, it is set here.
 * );
 * </pre></div>
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param array		$info The info array as returned by the ws_get_frame_info() function. This array is used to properly read the frame
 * @param resource	$filehandle An open and writable file handle to write the data to. (Optional)
 * @return array	An array that explains the outcome of the read operation.
 */
function ws_read_frame($info, $filehandle=false) { }

/**
 * Sends a frame to a web sockets peer
 * 
 * Simply pass a previously opened web socket stream and a message
 * to send to the peer. If you try to send a blank message
 * (a message with 0 length) then only the control bytes are sent with a zero frame size.
 * It is perfectly valid to send an empty message to the peer.
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param resource		$socket The web sockets stream connection to send to
 * @param string		$message The message to send to the peer
 * @param string|int	$type The type of message to send. Set to text, binary, close, continuation, ping, or pong. 
 * You can also set an integer from 0 to 15 that specifies an opcode to use if it is none of these types. (See RFC6455)
 * @param bool			$mask Whether or not to mask this frame. If you are acting as a websockets client, set to true
 * @param bool			$final Whether or not this is the final frame. If this is part of a fragmented message and more frames are coming, set this to false
 * @param bool			$rsv1 Whether or not to set the RSV1 bit on the frame. Used to support websocket extensions. (See RFC6455)
 * @param bool			$rsv2 Whether or not to set the RSV2 bit on the frame. Used to support websocket extensions. (See RFC6455)
 * @param bool			$rsv3 Whether or not to set the RSV3 bit on the frame. Used to support websocket extensions. (See RFC6455)
 * @return int|void		The number of bytes written (payload bytes only) or false on error. Careful, zero bytes does not mean a failure
 */
function ws_send_frame($socket, $message, $type='text', $mask=false, $final=true, $rsv1=false, $rsv2=false, $rsv3=false) { }

/**
 * Sends a close frame to a web sockets peer
 * You can slso send a close frame using the {@link ws_send_frame()} function
 * if you set the correct frame type, but using this function may be easier.
 *
 * Sends a close frame which tells the client to close the connection
 * This function DOES NOT actually close the PHP socket stream defined
 * by the $socket parameter. You have to close that after calling {@link ws_send_close()}.
 * The only thing this method does is send a valid close frame to the
 * client telling the client that the conversation is over.
 * Here are a list of possible close codes to pass as $code:
 * <div style="background:white;padding:10px;"><pre>Closure codes are as follows (The texts in parentheses are the default reason for that code if no reason is given)
 *  1000 - Normal closure (Closing this connection)
 *  1001 - Going away (This connection is going away)
 *  1002 - Protocol error (Protocol error)
 *  1003 - Cannot accept the data type (Cannot accept the specified data type)
 *  1007 - Received data that is not consistent with the data type (Received data that is not consistent with the specified data type)
 *  1008 - Received data that violates policy (The data that was sent violates policy)
 *  1009 - Message was too big to process (The message was too big to process)
 *  1010 - Invalid extension (I don't support the specified extension)
 *  1011 - Unexpected condition that prevented fulfillment of the request (Unexpected error)
 *
 *  Ranges
 *  0-999 - Not used
 *  1000-2999 - Normal protocol code range
 *  3000-3999 - Reserved for use by libraries, frameworks and must be registered
 *  4000-4999 - Private use codes
 * </pre></div>
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param resource	$socket The web sockets stream connection to close
 * @param int		$code The close code (see above)
 * @param string	$reason The reason why you are closing the connection (optional)
 * @param bool		$mask Whether or not to mask this frame. If your script is acting as a websockets client, set to true
 * @return int|void	The number of bytes written (payload bytes only) or false on error. Careful, zero bytes does not mean a failure
 */
function ws_send_close($socket, $code=1000, $reason='', $mask=false) { }

/**
 * Sends a ping frame to the web sockets peer
 * You can also send a ping frame using the {@link ws_send_frame()} function 
 * if you set the correct frame type, but using this function may be easier.
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param resource	$socket The web sockets stream connection to send a ping to
 * @param string	$message The message to send to the peer. (This message should be sent back in a pong later)
 * @param bool		$mask Whether or not to mask this frame. If your script is acting as a websockets client, set to true
 * @return int|void	The number of bytes written (payload bytes only) or false on error. Careful, zero bytes does not mean a failure
 */
function ws_send_ping($socket, $message='', $mask=false) { }

/**
 * Sends a pong frame to the web sockets peer
 * You can also send a pong frame using the {@link ws_send_frame()} function 
 * if you set the correct frame type, but using this function may be easier.
 * 
 * @see http://tools.ietf.org/html/rfc6455 Web Sockets Spec RFC6455
 * @param resource	$socket The web sockets stream connection to send a pong to
 * @param string	$message The message to send to the peer. (If responding to a ping, this should be the same message that was sent in the ping)
 * @param bool		$mask Whether or not to mask this frame. If your script is acting as a websockets client, set to true
 * @return int|void	The number of bytes written (payload bytes only) or false on error. Careful, zero bytes does not mean a failure
 */
function ws_send_pong($socket, $message='', $mask=false) { }
