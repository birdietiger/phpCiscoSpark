#!/bin/sh

# If you want to quickly rebuild this extension after having already built it, run this script
make clean all;
make install;